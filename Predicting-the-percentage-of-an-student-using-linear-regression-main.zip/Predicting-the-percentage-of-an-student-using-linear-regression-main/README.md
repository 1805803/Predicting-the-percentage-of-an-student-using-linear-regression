https://www.youtube.com/watch?v=_udWRtY_eEg
# Predicting-the-percentage-of-an-student-using-linear-regression
Predict the percentage of an student based on the no. of study hours.
Language used- Python
